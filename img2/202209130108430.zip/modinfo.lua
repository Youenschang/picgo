name = "show range"
description = "It can check range of your machines:\n-Ice Flingomatic\n-Sprinkler\n-Oscillating Fan\n-Lightning Rod"
author = "Real author is _Q_"
version = "2.0.5"

forumthread = ""

api_version = 6

dont_starve_compatible = true
reign_of_giants_compatible = true
shipwrecked_compatible = true
hamlet_compatible = true

icon_atlas = "modicon.xml"
icon = "modicon.tex"

configuration_options =
{
    {
        name = "Range Check Time",
        options =
        {
            {description = "Short", data = "short"},
			{description = "Default", data = "default"},
			{description = "Long", data = "long"},
			{description = "Longer", data = "longer"},
			{description = "Longest", data = "longest"},
			{description = "Always", data = "always"},
        },
        default = "default",
    }
}